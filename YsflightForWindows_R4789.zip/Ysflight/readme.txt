
YS Flight Simulator
Version 20130805

 By CaptainYS
  E-Mail PEB01130@nifty.com
  URL    http://www.ysflight.com



Japanese -> Please refer to jreadme.txt
English  -> Please refer to ereadme.txt



System requirement
  YSFLIGHT for Windows: Windows XP SP3/Vista/7
  YSFLIGHT for Mac OSX: Intel Mac OS 10.5.8 or newer (need 64-bit CPU and OS)
  YSFLIGHT for Linux: Tested on Ubuntu 12.04



