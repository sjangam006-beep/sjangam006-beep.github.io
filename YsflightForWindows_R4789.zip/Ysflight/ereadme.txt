YS Flight Simulator
Version 20150406

 By CaptainYS
  E-Mail PEB01130@nifty.com
  URL    http://www.ysflight.com



Required Environment
  YSFLIGHT for Windows: Windows XP SP2/Vista/7/8.x
  YSFLIGHT for Mac OSX: Intel Mac OS 10.6.8 or newer (need 64-bit CPU and OS)
  YSFLIGHT for Linux: Tested on Ubuntu 12.04


How to install
  I think you successfully downloaded and extracted the
  files. Please double click SETUP.EXE in the same
  directory as this file, and follow the instruction to
  install.

  You need to have an administrator priviledge to install 
  the program.

  If you don't have an administrator priviledge, change
  the filename of SETUP.EXE to SETUP.ZIP.  Then you can
  manually extract files with an conventional extractor 
  (such as WinZip).  And then double-click on fsmaino.exe or
  fsmaindx.exe to run YSFLIGHT.
  
  When you manually extract files, please make sure you 
  re-construct the directory structure.  If you see all 
  the files in one directory and no sub-directories, you 
  did not extract the files right.  In that case, please
  re-do extraction.



How to use
[Mac OSX]
  If you extract the archive, you will get a bundle called YSFLIGHT.  Double click it to start the program.


[Windows]
  Please refer to the manual. You can open the manual by
  choosing

    Start menu
     -> Program
      -> YS FLIGHT SIMULATOR
       -> HELP(English)


[Linux]
  Extract files, and type ysflight2 or ysflight from console, or double click to start the program.



THANK YOU FOR DOWNLOADING MY SOFTWARE.

    Soji Yamakawa
      PEB01130@nifty.com
      http://www.ysflight.com
